module.exports = {
    images: {
      domains: ['0.0.0.0'],
    },
  }