export const ProductCategories = {
    CarBatteries: 'CarBatteries',
    StartCable: 'StartCable',
    StarterChargers: 'StarterChargers',
    ContactGrease: 'ContactGrease',
    DistilledWater: 'DistilledWater',
    BatteryTerminals: 'BatteryTerminals',
    BatteryTesters: 'BatteryTesters'
}