export const controlsConstants = {
    OPEN_CART: 'OPEN_CART',
    CLOSE_CART: 'CLOSE_CART'
}