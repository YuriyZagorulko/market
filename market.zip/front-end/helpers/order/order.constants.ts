export enum deliveryTypes {
    newPost = 'NEW_POST',
    newPostCourier = 'NEW_POST_COURIER',
    justin = 'JUSTIN',
}