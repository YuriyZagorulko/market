export interface ILogin{
    token: string
}