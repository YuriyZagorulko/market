import { IProduct } from './responces/products'
export interface IPaginatedData{
    data: IProduct []
}