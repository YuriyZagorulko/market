from .register import RegisterView
from .login import MyObtainTokenPairView