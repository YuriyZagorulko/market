from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = 'marketBackend.apps.auth'
    label = 'marketAuth'
