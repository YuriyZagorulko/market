from .product import ProductView
from .index import IndexView
from .main import MainView
from .order import OrderView
from .order import CitiesNPView
from .order import OfficesNPView
from .order import ConfirmOrderView
from .search import SearchViewSet