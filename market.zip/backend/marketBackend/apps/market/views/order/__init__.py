from .order import OrderView
from .order import ConfirmOrderView
from .shipping import CitiesNPView
from .shipping import OfficesNPView
