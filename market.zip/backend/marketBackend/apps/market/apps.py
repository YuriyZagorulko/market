from django.apps import AppConfig


class MarketConfig(AppConfig):
    name = 'marketBackend.apps.market'
